<?php
session_start();
include 'koneksi.php';

// Check database connection
if (!$koneksi) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Verify session exists
if (!isset($_SESSION['idsi'])) {
    die("<script>alert('Session tidak valid, silakan login kembali'); window.location='logout.php';</script>");
}

// Get student data
$id_siswa = $_SESSION['idsi'];
$query_siswa = mysqli_query($koneksi, "SELECT * FROM tb_karyawan WHERE id_karyawan = '$id_siswa'");
$siswa = mysqli_fetch_array($query_siswa);

// Available themes
$available_themes = ['light', 'dark', 'anime', 'car', 'aesthetic'];
$default_theme = 'light';

// Get current theme from database if available, otherwise use default
$current_theme = $siswa['theme_preference'] ?? $default_theme;
$_SESSION['current_theme'] = $current_theme;

// Get leaderboard data
$query_leaderboard = mysqli_query($koneksi, "
    SELECT 
        k.id_karyawan,
        k.nama,
        COUNT(CASE WHEN t.keterangan = 'Hadir' THEN 1 END) AS total_hadir,
        COUNT(CASE WHEN t.keterangan = 'Izin' THEN 1 END) AS total_izin,
        COUNT(CASE WHEN t.keterangan = 'Sakit' THEN 1 END) AS total_sakit,
        -- Hitung hari yang seharusnya absen tapi tidak diisi
        (SELECT COUNT(DISTINCT DATE(waktu)) FROM tb_keterangan) - 
        COUNT(DISTINCT DATE(t.waktu)) AS total_alpa,
        -- Hitung total poin
        (COUNT(CASE WHEN t.keterangan = 'Hadir' THEN 1 END) * 10) + 
        (COUNT(CASE WHEN t.keterangan = 'Izin' THEN 1 END) * -5) + 
        (COUNT(CASE WHEN t.keterangan = 'Sakit' THEN 1 END) * -5) - 
        ((SELECT COUNT(DISTINCT DATE(waktu)) FROM tb_keterangan) - 
        COUNT(DISTINCT DATE(t.waktu))) * 15 AS total_poin
    FROM 
        tb_karyawan k
    LEFT JOIN 
        tb_keterangan t ON k.id_karyawan = t.id_karyawan
    GROUP BY 
        k.id_karyawan, k.nama
    ORDER BY 
        total_poin DESC
");

if (!$query_leaderboard) {
    die("Error in leaderboard query: " . mysqli_error($koneksi));
}
$leaderboard = mysqli_fetch_all($query_leaderboard, MYSQLI_ASSOC);

// Get current user's position
$current_user_position = 0;
foreach ($leaderboard as $index => $user) {
    if ($user['id_karyawan'] == $id_siswa) {
        $current_user_position = $index + 1;
        break;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard | IT Club Trimulia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --biru-tua: #1a3e72;
            --biru-muda: #4a8fe7;
            --hijau: #28a745;
            --kuning: #ffc107;
            --merah: #dc3545;
            --ungu: #6f42c1;
            --bg-light: #f8fafc;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        .card-leaderboard {
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
            overflow: hidden;
            transition: transform 0.3s ease;
            background: white;
            margin-bottom: 20px;
            border-top: 5px solid var(--biru-tua);
        }
        
        .card-header-leaderboard {
            background: linear-gradient(135deg, var(--biru-tua) 0%, var(--biru-muda) 100%);
            color: white;
            padding: 1.5rem;
            border-bottom: none;
        }
        
        .rank-badge {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: white;
        }
        
        .rank-1 {
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
        }
        
        .rank-2 {
            background: linear-gradient(135deg, #C0C0C0 0%, #A9A9A9 100%);
        }
        
        .rank-3 {
            background: linear-gradient(135deg, #CD7F32 0%, #A0522D 100%);
        }
        
        .rank-other {
            background: var(--biru-muda);
        }
        
        .current-user {
            background-color: rgba(74, 143, 231, 0.1);
            border-left: 4px solid var(--biru-muda);
        }
        
        /* Hamburger Menu */
        .hamburger-menu {
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1000;
            cursor: pointer;
            background: rgba(255, 255, 255, 0.8);
            border-radius: 8px;
            padding: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .hamburger-menu span {
            display: block;
            width: 25px;
            height: 3px;
            background-color: var(--biru-tua);
            margin: 5px 0;
            transition: all 0.3s ease;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            left: -300px;
            width: 250px;
            height: 100%;
            background: white;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            z-index: 999;
            transition: all 0.3s ease;
            padding-top: 70px;
        }
        
        .sidebar.active {
            left: 0;
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar-menu li {
            padding: 15px 20px;
            border-bottom: 1px solid #f0f0f0;
            transition: all 0.3s;
        }
        
        .sidebar-menu li:hover {
            background-color: #f8f9fa;
        }
        
        .sidebar-menu li a {
            color: #333;
            text-decoration: none;
            display: flex;
            align-items: center;
        }
        
        .sidebar-menu li a i {
            margin-right: 10px;
            color: var(--biru-muda);
        }
        
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 998;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }
        
        .overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        /* Adjust container padding when sidebar is open */
        .container {
            transition: all 0.3s;
        }
        
        .container.sidebar-open {
            padding-left: 270px;
        }
        
        @media (max-width: 768px) {
            .container.sidebar-open {
                padding-left: 20px;
            }
        }
        
        /* Light Mode (Default) */
        body.light-mode {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            color: #000103;
        }

        /* Dark Mode */
        body.dark-mode {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #f8f9fa;
        }

        body.dark-mode .card-leaderboard,
        body.dark-mode .sidebar {
            background-color: #1e293b;
            color: #f8f9fa;
        }

        /* ANIME MODE */
        body.anime-mode {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), 
                        url('https://img.freepik.com/premium-photo/beautiful-women-who-burns-sunset-with-lighter-beautiful-red-sky-lighter-light-illustration-mi_605905-1782.jpg?semt=ais_hybrid&w=740') no-repeat center center fixed;
            background-size: cover;
        }

        body.anime-mode .card-leaderboard,
        body.anime-mode .sidebar {
            background-color: rgba(30, 41, 59, 0.7);
            backdrop-filter: blur(12px);
            color: #000103;
            border: 1px solid rgba(245, 158, 11, 0.4);
            box-shadow: 0 8px 32px 0 rgba(180, 83, 9, 0.2);
        }

        /* CAR MODE */
        body.car-mode {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), 
                        url('https://img.freepik.com/free-photo/anime-car-city_23-2151710981.jpg?ga=GA1.1.536428855.1750071400&semt=ais_hybrid&w=740') no-repeat center center fixed;
            background-size: cover;
        }

        body.car-mode .card-leaderboard,
        body.car-mode .sidebar {
            background-color: rgba(30, 41, 59, 0.7);
            backdrop-filter: blur(12px);
            color: #000103;
            border: 1px solid rgba(220, 38, 38, 0.4);
            box-shadow: 0 8px 32px 0 rgba(153, 27, 27, 0.2);
        }

        /* AESTHETIC MODE */
        body.aesthetic-mode {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), 
                        url('https://images.unsplash.com/photo-1579547945413-497e1b99dac0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80') no-repeat center center fixed;
            background-size: cover;
        }

        body.aesthetic-mode .card-leaderboard,
        body.aesthetic-mode .sidebar {
            background-color: rgba(109, 40, 217, 0.6);
            backdrop-filter: blur(12px);
            color: #000103;
            border: 1px solid rgba(139, 92, 246, 0.4);
            box-shadow: 0 8px 32px 0 rgba(109, 40, 217, 0.2);
        }
    </style>
</head>
<body class="<?php echo htmlspecialchars($current_theme); ?>-mode">
   <!-- Hamburger Menu -->
    <div class="hamburger-menu" id="hamburgerMenu">
        <span></span>
        <span></span>
        <span></span>
    </div>
    
    <!-- Sidebar Menu -->
    <div class="sidebar" id="sidebar">
        <ul class="sidebar-menu">
            <li>
                <a href="awal.php">
                    <i class="fas fa-home"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="absen.php">
                    <i class="fas fa-calendar-check"></i> Absen
                </a>
            </li>
            <li>
                <a href="kas.php">
                    <i class="fas fa-wallet"></i> Data Kas
                </a>
            </li>
            <li>
                <a href="riwayat.php">
                    <i class="fas fa-history"></i> Riwayat Kehadiran
                </a>
            </li>
            <li>
                <a href="statistik.php">
                    <i class="fas fa-chart-line"></i> Statistik
                </a>
            </li>
            <li>
                <a href="projek.php">
                    <i class="fas fa-project-diagram"></i> Lihat Projek
                </a>
            </li>
            <li>
                <a href="leaderboard.php">
                    <i class="fas fa-trophy"></i> Leaderboard
                </a>
            </li>
            <li>
                <a href="agenda.php">
                    <i class="fas fa-calendar-alt"></i> Agenda & Pengumuman
                </a>
            </li>
        </ul>
    </div>

    <div class="overlay" id="overlay"></div>
    
    <div class="container py-5" id="mainContainer">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card card-leaderboard">
                    <div class="card-header card-header-leaderboard text-center">
                        <h3><i class="fas fa-trophy me-2"></i> LEADERBOARD KEHADIRAN</h3>
                        <p class="mb-0">Peringkat Anda: #<?php echo $current_user_position; ?></p>
                    </div>
                    
                    <div class="card-body p-4">
                        <?php if (empty($leaderboard)): ?>
                            <div class="alert alert-info text-center">
                                <i class="fas fa-info-circle me-2"></i> Belum ada data leaderboard.
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th style="width: 60px;">Rank</th>
                                            <th>Nama</th>
                                            <th>Hadir</th>
                                            <th>Izin</th>
                                            <th>Sakit</th>
                                            <th>Alpa</th>
                                            <th>Total Poin</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($leaderboard as $index => $user): ?>
                                            <tr class="<?php echo ($user['id_karyawan'] == $id_siswa) ? 'current-user' : ''; ?>">
                                                <td>
                                                    <div class="rank-badge <?php echo ($index < 3) ? 'rank-'.($index+1) : 'rank-other'; ?>">
                                                        <?php echo $index + 1; ?>
                                                    </div>
                                                </td>
                                                <td><?php echo htmlspecialchars($user['nama']); ?></td>
                                                <td><?php echo $user['total_hadir']; ?></td>
                                                <td><?php echo $user['total_izin']; ?></td>
                                                <td><?php echo $user['total_sakit']; ?></td>
                                                <td><?php echo $user['total_alpa']; ?></td>
                                                <td><strong><?php echo $user['total_poin'] ?? 0; ?></strong></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="mt-4">
                                <h5><i class="fas fa-info-circle me-2"></i> Sistem Poin:</h5>
                                <ul class="list-group">
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Hadir
                                        <span class="badge bg-success rounded-pill">+10 poin</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Izin
                                        <span class="badge bg-primary rounded-pill">-5 poin</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Sakit
                                        <span class="badge bg-warning rounded-pill">-5 poin</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Alpa
                                        <span class="badge bg-danger rounded-pill">-15 poin</span>
                                    </li>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Hamburger Menu Toggle
        const hamburgerMenu = document.getElementById('hamburgerMenu');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');
        const mainContainer = document.getElementById('mainContainer');

        hamburgerMenu.addEventListener('click', function() {
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
            mainContainer.classList.toggle('sidebar-open');
            
            // Animate hamburger icon
            const spans = this.querySelectorAll('span');
            if (sidebar.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translate(5px, 6px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(5px, -6px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });

        // Close sidebar when clicking on overlay
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
            mainContainer.classList.remove('sidebar-open');
            
            // Reset hamburger icon
            const spans = hamburgerMenu.querySelectorAll('span');
            spans[0].style.transform = 'none';
            spans[1].style.opacity = '1';
            spans[2].style.transform = 'none';
        });
    </script>
</body>
</html>